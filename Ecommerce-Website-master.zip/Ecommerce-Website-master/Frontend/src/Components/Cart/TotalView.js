import { Box, Typography, makeStyles } from '@material-ui/core'
import clsx from 'clsx';
import {useEffect, useState} from 'react'
import CartItem from './CartItem';

const useStyle = makeStyles(theme=>({
    component: {
        // width: "30%",
        marginLeft: 15,
        backgroundColor: '#fff',
        [theme.breakpoints.down('sm')]: {
            marginLeft: 5,
            padding: '15px 0px',
        }
    },
    header: {
        padding: "16px 24px",
        borderBottom:'1px solid #f0f0f0'
    },
    container:{
        padding:'15px 24px',
        '& > *':{
            marginTop:20,
            fontSize:14
        }
    },
    greytextcolor:{
        color:"#878787"
    },
    price:{
        float:'right'
    },
    total:{
        fontWeight:600,
        fontSize:18,
        borderTop:'1px dashed #e0e0e0',
        padding:"20px 0",
        borderBottom:'1px dashed #e0e0e0',
    }
}))
const TotalView = ({ cartItems }) => {
    const classes = useStyle();
    const [price,setprice]=useState(0);
    const [discount,setdiscount]=useState(0);
    useEffect(()=>{
      totalamt();
    },[cartItems])
    const totalamt=()=>{
        let price=0,discount=0;
        cartItems.map(item=>{
            price+=item.price.mrp;
            discount+=(item.price.mrp-item.price.cost);
        })
        setprice(price);
        setdiscount(discount);
    }
    return (
        <Box className={classes.component}>
            <Box className={classes.header}>
                <Typography className={classes.greytextcolor}>PRICE DETAILS</Typography>
            </Box>
            <Box className={classes.container}>
                <Typography>Price ({cartItems.length} item) <span className={classes.price}>₹{price}</span> </Typography>
                <Typography>Discount <span className={classes.price}>-₹{discount}</span></Typography>
                <Typography>Delivery Charges <span className={classes.price}>₹40</span></Typography>
                <Typography className={classes.total}>Total Amount <span className={classes.price}>₹{price-discount+40}</span></Typography>
                <Typography style={{color:"green"}}>You will save ₹{discount-40} on this Order </Typography>
            </Box>
        </Box>
    )
}

export default TotalView;