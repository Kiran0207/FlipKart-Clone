export const ADDTOCART_SUCCESS="ADDTOCARTSuccess"
export const ADDTOCART_FAIL="ADDTOCARTFail"

export const REMOVE_FROM_CART="RemoveFromCart"