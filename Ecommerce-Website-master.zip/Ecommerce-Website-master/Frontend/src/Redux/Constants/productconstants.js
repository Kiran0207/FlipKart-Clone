export const GET_PRODUCT_SUCCESS="getProductSuccess"
export const GET_PRODUCT_FAIL="getProductFail"

export const GET_PRODUCT_DETAIL_SUCCESS="getProduct_DETAILSuccess"
export const GET_PRODUCT_DETAIL_FAIL="getProduct_DETAILFail"

